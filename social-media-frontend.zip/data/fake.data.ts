export const USER = {
  1: {
    firstName: "Дима",
    lastName: "Абдукаримов",
    username: "@official_hexvel",
    avatar: "/profile-photo.webp",
  },
};
