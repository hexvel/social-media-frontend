export default function PhotosLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <div>{children}</div>;
}
