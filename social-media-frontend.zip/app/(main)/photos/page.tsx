export default function PhotosPage() {
  return <div>PhotosPage</div>;
}
