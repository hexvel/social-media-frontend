"use client";

import Loader from "@/components/Loader";
import Post from "@/components/Post";
import RightSidebar from "@/components/RightSidebar";
import { useGetRecommendationPostsQuery } from "@/services/recommendation.service";

export default function HomePage() {
  const { data: posts, isLoading } = useGetRecommendationPostsQuery();

  if (isLoading)
    return (
      <div className='w-full flex justify-center items-center'>
        <Loader />
      </div>
    );

  if (!posts) return <div>No posts</div>;

  console.log(posts);

  return (
    <main className='flex w-full min-w-0 gap-5'>
      <div className='flex flex-col items-center w-full min-w-0 space-y-5'>
        {posts?.map(({ post }, index) => (
          <Post key={index} {...post} />
        ))}
      </div>

      <RightSidebar />
    </main>
  );
}
